var config = {
    map: {
        '*': {
            magearrayFileUpload:'MageArray_OrderAttachments/js/file-upload'
        }
    }
}; 